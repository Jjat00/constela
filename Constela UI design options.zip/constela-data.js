// Constela — universo de demo (determinista). Sin métricas ni testimonios reales.
const NAMES = ["Tú","Camila Restrepo","Andrés Mejía","Valentina Ruiz","Mateo Cárdenas","Sofía Herrera","Daniel Ocampo","Laura Bermúdez","Julián Ospina","Mariana Vélez","Sebastián Ríos","Paula Gutiérrez","Tomás Aguirre","Isabela Moreno","Nicolás Peña","Ana Lucía Rojas","Felipe Zapata","Carolina Duque","Esteban Muñoz","Juliana Salazar","Ricardo Lozano","Manuela Castaño","Óscar Villalba","Sara Quintero","Alejandro Pardo","Natalia Cifuentes","Diego Arango","Gabriela Toro","Iván Betancur","Lucía Navarro","Camilo Sáenz","Verónica Aristizábal","Hugo Palacios","Elena Cortés","Martín Escobar","Renata Guzmán"];
const ROLES = ["Diseño","Ingeniería","Producto","Data","Growth","Fundador"];
const INTERESES = ["IA","Realtime","Grafos","Hardware","Comunidad","Sistemas de diseño"];
const INTENCIONES = ["Busco equipo","Contrato","Aprendo","Mentoría","Invierto","Colaboro"];
const CLASSES = [
  { c: "B", halo: "#9DB4FF" },
  { c: "A", halo: "#CDD8FF" },
  { c: "F", halo: "#E6ECFF" },
  { c: "K", halo: "#FFD9A8" },
  { c: "M", halo: "#FFB380" }
];

function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function buildUniverse(seed = 11, n = 36) {
  const rand = mulberry32(seed);
  const stars = [];
  for (let i = 0; i < n; i++) {
    const a = i * 2.39996 + (rand() - 0.5) * 0.5;
    const r = i === 0 ? 0 : (0.16 + 0.84 * Math.sqrt(i / n)) * (0.86 + rand() * 0.28);
    const sp = CLASSES[i === 0 ? 3 : Math.floor(rand() * CLASSES.length)];
    stars.push({
      id: i,
      name: NAMES[i],
      isSun: i === 0,
      spectral: sp.c,
      halo: i === 0 ? "#FFD97A" : sp.halo,
      x: 500 + Math.cos(a) * r * 410,
      y: 500 + Math.sin(a) * r * 400,
      role: i === 0 ? "Diseño" : ROLES[Math.floor(rand() * ROLES.length)],
      interes: INTERESES[Math.floor(rand() * INTERESES.length)],
      intencion: INTENCIONES[Math.floor(rand() * INTENCIONES.length)],
      twinkle: 3 + rand() * 3,
      delay: rand() * 4,
      deg: 0
    });
  }
  stars.forEach(s => { s.tags = [s.role, s.interes, s.intencion]; });

  const adj = stars.map(() => new Set());
  const edges = [];
  const link = (a, b) => {
    if (a === b || adj[a].has(b)) return;
    adj[a].add(b); adj[b].add(a);
    edges.push({ a, b });
  };
  for (let i = 1; i < n; i++) {
    const near = stars.slice(0, i)
      .map(s => ({ id: s.id, d: (s.x - stars[i].x) ** 2 + (s.y - stars[i].y) ** 2 }))
      .sort((p, q) => p.d - q.d)
      .slice(0, 5);
    const first = near[Math.floor(rand() * Math.min(2, near.length))].id;
    link(i, first);
    // cierre triádico: engancha a un vecino del vecino
    const fn = [...adj[first]].filter(x => x !== i);
    if (fn.length && rand() < 0.72) link(i, fn[Math.floor(rand() * fn.length)]);
    if (rand() < 0.3 && near[2]) link(i, near[2].id);
    if (i < 7) link(i, 0);
  }
  stars.forEach(s => { s.deg = adj[s.id].size; });
  stars.forEach(s => { s.mag = s.isSun ? 5.4 : 1 + Math.min(s.deg, 7) * 0.34; });

  const triads = [];
  for (const e of edges) {
    const shared = [...adj[e.a]].filter(x => x > e.b && adj[e.b].has(x));
    for (const c of shared) {
      triads.push({
        ids: [e.a, e.b, c],
        mine: e.a === 0 || e.b === 0 || c === 0,
        pts: [stars[e.a], stars[e.b], stars[c]].map(s => `${s.x.toFixed(1)},${s.y.toFixed(1)}`).join(" ")
      });
    }
  }

  const mine = [...adj[0]];
  const stats = {
    conexiones: mine.length,
    triangulos: triads.filter(t => t.mine).length,
    magnitud: (1.1 + mine.length * 0.14).toFixed(1)
  };

  const mins = [2, 6, 14, 27, 41];
  const actividad = edges.slice(-5).reverse().map((e, i) => ({
    id: i,
    a: stars[e.a].name,
    b: stars[e.b].name,
    hace: mins[i] + " min"
  }));

  const sugerencias = stars
    .filter(s => !s.isSun && !adj[0].has(s.id) && s.tags.some(t => stars[0].tags.includes(t) || t === "Busco equipo"))
    .slice(0, 3)
    .map(s => ({ id: s.id, name: s.name, role: s.role, why: s.intencion }));

  return { stars, edges, triads, adj, stats, actividad, sugerencias, me: stars[0], roles: ROLES, intenciones: INTENCIONES };
}
